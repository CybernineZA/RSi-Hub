import { createAdminClient } from '@/lib/supabase/admin'
import type { Role } from '@/lib/rsi/roles'

type DiscordInfo = { discordId: string | null; discordName: string | null; avatarUrl: string | null }

function pick<T>(...vals: Array<T | null | undefined>): T | null {
  for (const v of vals) if (v !== null && v !== undefined && String(v).length > 0) return v as T
  return null
}

export function getDiscordInfoFromUser(user: any): DiscordInfo {
  const meta = (user?.user_metadata ?? {}) as Record<string, any>
  const identities = (user?.identities ?? []) as any[]

  const discordIdentity =
    identities.find((i) => i?.provider === 'discord') ??
    identities.find((i) => i?.identity_data?.provider === 'discord') ??
    identities[0]

  const identityData = (discordIdentity?.identity_data ?? {}) as Record<string, any>

  // Supabase often stores OAuth subject as `provider_id` or `sub`
  const discordId = pick<string>(
    meta.provider_id,
    meta.sub,
    identityData.provider_id,
    identityData.sub,
    discordIdentity?.id,
    identityData.id,
    meta.id
  )

  const discordName = pick<string>(
    meta.full_name,
    meta.name,
    meta.user_name,
    meta.preferred_username,
    identityData.full_name,
    identityData.name,
    identityData.user_name,
    identityData.preferred_username
  )

  const avatarUrl = pick<string>(meta.avatar_url, meta.picture, identityData.avatar_url, identityData.picture)

  return {
    discordId: discordId ? String(discordId) : null,
    discordName: discordName ? String(discordName) : null,
    avatarUrl: avatarUrl ? String(avatarUrl) : null,
  }
}

export async function ensureProvisionedMembership(params: {
  userId: string
  discordId: string | null
  discordName: string | null
  avatarUrl: string | null
}): Promise<{ ok: true; role: Role } | { ok: false; reason: 'not_approved' | 'missing_discord_id' | 'missing_regiment' }> {
  const { userId, discordId, discordName, avatarUrl } = params

  if (!discordId) return { ok: false, reason: 'missing_discord_id' }

  const admin = createAdminClient()
  const slug = (process.env.RSI_REGIMENT_SLUG ?? 'rsi').trim()

  const { data: regiment, error: regErr } = await admin.from('regiments').select('id').eq('slug', slug).maybeSingle()
  if (regErr || !regiment?.id) return { ok: false, reason: 'missing_regiment' }

  // Bootstrap commander (first login) — bypass approval requirement
  const bootstrapDiscordId = (process.env.RSI_BOOTSTRAP_DISCORD_ID ?? '').trim()
  const bootstrapRole = ((process.env.RSI_BOOTSTRAP_ROLE ?? 'commander').trim() as Role) || 'commander'

  let finalRole: Role | null = null

  if (bootstrapDiscordId && discordId === bootstrapDiscordId) {
    finalRole = bootstrapRole
  } else {
    // Must have an accepted recruit application
    const { data: app, error: aErr } = await admin
      .from('recruit_applications')
      .select('status')
      .eq('regiment_id', regiment.id)
      .eq('discord_user_id', discordId)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()

    if (aErr || !app || app.status !== 'accepted') return { ok: false, reason: 'not_approved' }
    finalRole = 'member'
  }

  // Upsert profile + membership using service role (bypasses RLS)
  const profilePayload = {
    id: userId,
    regiment_id: regiment.id,
    discord_id: discordId,
    discord_name: discordName ?? null,
    display_name: discordName ?? null,
    avatar_url: avatarUrl ?? null,
  }

  const { error: pErr } = await admin.from('profiles').upsert(profilePayload, { onConflict: 'id' })
  if (pErr) throw new Error(`profiles upsert failed: ${pErr.message}`)

  const { error: mErr } = await admin
    .from('memberships')
    .upsert({ profile_id: userId, regiment_id: regiment.id, role: finalRole }, { onConflict: 'profile_id' })
  if (mErr) throw new Error(`memberships upsert failed: ${mErr.message}`)

  return { ok: true, role: finalRole }
}
