import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { requireMembership } from '@/lib/rsi/session'
import { atLeast, type Role } from '@/lib/rsi/roles'

function json(data: any, status = 200) {
  return NextResponse.json(data, { status })
}

type Body =
  | {
      kind: 'individual'
      war_id: string
      title: string
      lines: { item_id: string; qty_required: number }[]
    }
  | {
      kind: 'container'
      war_id: string
      yard_id: string
      label: string
      lines: { item_id: string; qty_required: number }[]
    }

const MAX_CONTAINER_SLOTS = 60

export async function POST(req: Request) {
  const supabase = await createClient()
  const { user, membership } = await requireMembership(supabase)

  const role = membership.role as Role
  if (!atLeast(role, 'member')) return json({ error: 'Forbidden' }, 403)

  let body: Body
  try {
    body = (await req.json()) as Body
  } catch {
    return json({ error: 'Invalid JSON body' }, 400)
  }

  try {
    if (body.kind === 'individual') {
      const title = String(body.title ?? '').trim()
      if (!body.war_id || !title) return json({ error: 'Missing war_id or title' }, 400)

      const lines = Array.isArray(body.lines) ? body.lines : []
      if (lines.length === 0) return json({ error: 'Add at least 1 item line' }, 400)

      const { data: order, error: oErr } = await supabase
        .from('orders')
        .insert({
          war_id: body.war_id,
          type: 'production',
          title,
          status: 'open',
          created_by: user.id,
        })
        .select('id')
        .single()

      if (oErr) return json({ error: oErr.message }, 400)

      const items = lines
        .map((l) => ({
          order_id: order.id,
          item_id: l.item_id,
          qty_required: Math.max(1, Math.floor(Number(l.qty_required ?? 0))),
        }))
        .filter((l) => !!l.item_id)

      const { error: iErr } = await supabase.from('order_items').insert(items)
      if (iErr) return json({ error: iErr.message }, 400)

      return json({ ok: true, order_id: order.id })
    }

    // Container order
    const label = String(body.label ?? '').trim()
    if (!body.war_id || !body.yard_id || !label) return json({ error: 'Missing war_id, yard_id or label' }, 400)

    const lines = Array.isArray(body.lines) ? body.lines : []
    if (lines.length === 0) return json({ error: 'Add at least 1 item line' }, 400)

    const itemIds = Array.from(new Set(lines.map((l) => l.item_id).filter(Boolean)))
    const { data: itemMeta, error: metaErr } = await supabase
      .from('items')
      .select('id, slot_count')
      .in('id', itemIds)

    if (metaErr) return json({ error: metaErr.message }, 400)

    const slotById = new Map<string, number>()
    for (const it of itemMeta ?? []) slotById.set(it.id, Number(it.slot_count ?? 1) || 1)

    const normalized = lines
      .map((l) => {
        const qty_required = Math.max(1, Math.floor(Number(l.qty_required ?? 0)))
        const slot_count = slotById.get(l.item_id) ?? 1
        return { item_id: l.item_id, qty_required, slot_count }
      })
      .filter((l) => !!l.item_id)

    const requiredSlots = normalized.reduce((acc, l) => acc + (l.slot_count || 1) * l.qty_required, 0)
    if (requiredSlots > MAX_CONTAINER_SLOTS) {
      return json(
        {
          error: 'Container over capacity',
          details: `Needs ${requiredSlots} slots but max is ${MAX_CONTAINER_SLOTS}. Split into multiple containers.`,
        },
        400
      )
    }

    const { data: container, error: cErr } = await supabase
      .from('containers')
      .insert({
        war_id: body.war_id,
        yard_id: body.yard_id,
        label,
        state: 'filling',
        max_slots: MAX_CONTAINER_SLOTS,
        current_slots: 0,
        created_by: user.id,
      })
      .select('id')
      .single()

    if (cErr) return json({ error: cErr.message }, 400)

    const ci = normalized.map((l) => ({
      container_id: container.id,
      item_id: l.item_id,
      qty_required: l.qty_required,
      qty_done: 0,
      slot_count: l.slot_count || 1,
    }))

    const { error: ciErr } = await supabase.from('container_items').insert(ci)
    if (ciErr) {
      await supabase.from('containers').delete().eq('id', container.id)
      return json({ error: ciErr.message }, 400)
    }

    return json({ ok: true, container_id: container.id, required_slots: requiredSlots, max_slots: MAX_CONTAINER_SLOTS })
  } catch (e: any) {
    return json({ error: String(e?.message ?? e) }, 500)
  }
}
