import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { requireMembership } from '@/lib/rsi/session'
import { atLeast, type Role } from '@/lib/rsi/roles'

function json(data: any, status = 200) {
  return NextResponse.json(data, { status })
}

const ALLOWED = new Set(['open', 'in_progress', 'complete', 'cancelled'])

export async function PATCH(req: Request, { params }: { params: { orderId: string } }) {
  const supabase = await createClient()
  const { membership } = await requireMembership(supabase)

  const role = membership.role as Role
  if (!atLeast(role, 'member')) return json({ error: 'Forbidden' }, 403)

  let body: any
  try {
    body = await req.json()
  } catch {
    return json({ error: 'Invalid JSON body' }, 400)
  }

  const status = String(body?.status ?? '').trim()
  if (!ALLOWED.has(status)) return json({ error: 'Invalid status' }, 400)

  const { data, error } = await supabase
    .from('orders')
    .update({ status })
    .eq('id', params.orderId)
    .select('id,status')
    .single()

  if (error) return json({ error: error.message }, 400)
  return json({ ok: true, order: data })
}
