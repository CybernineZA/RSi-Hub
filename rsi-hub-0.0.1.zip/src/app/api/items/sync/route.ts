import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { requireMembership } from '@/lib/rsi/session'
import { atLeast, type Role } from '@/lib/rsi/roles'

function json(data: any, status = 200) {
  return NextResponse.json(data, { status })
}

// Public source (used by FoxholeLogi) with item definitions.
// Override with FOXHOLE_ITEM_SOURCE_URL in .env.local if needed.
const DEFAULT_SOURCE_URL = 'https://foxholelogi.com/assets/foxhole.json'

// Optional icon base URL for future UI (configurable).
const DEFAULT_ICON_BASE_URL = 'https://foxholelogi.com/assets/icons/'

function slugify(input: string) {
  return input
    .toLowerCase()
    .replace(/\.png$/i, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
}

function normalizeUnit(category?: string, itemClass?: string): 'crate' | 'item' | 'vehicle' {
  const c = (category ?? '').toLowerCase()
  const cls = (itemClass ?? '').toLowerCase()
  if (c.includes('vehicle') || c.includes('vehicles') || cls.includes('vehicle') || cls.includes('tank')) return 'vehicle'
  return 'crate'
}

function coerceFaction(value: any): string[] {
  if (!value) return []
  if (Array.isArray(value)) return value.map(String).filter(Boolean)
  if (typeof value === 'string') return [value].filter(Boolean)
  return []
}

export async function POST() {
  const supabase = await createClient()
  const { membership } = await requireMembership(supabase)

  const role = membership.role as Role
  if (!atLeast(role, 'officer')) return json({ error: 'Forbidden' }, 403)

  const url = (process.env.FOXHOLE_ITEM_SOURCE_URL || DEFAULT_SOURCE_URL).trim()

  let raw: any
  try {
    const res = await fetch(url, { cache: 'no-store' })
    if (!res.ok) {
      const text = await res.text().catch(() => '')
      return json({ error: `Fetch failed (${res.status})`, details: text.slice(0, 200) }, 400)
    }
    raw = await res.json()
  } catch (e: any) {
    return json({ error: `Fetch failed: ${String(e?.message ?? e)}` }, 400)
  }

  const list = Array.isArray(raw) ? raw : Array.isArray(raw?.items) ? raw.items : []
  if (!Array.isArray(list) || list.length === 0) return json({ error: 'No items returned by source' }, 400)

  const iconBase = (process.env.FOXHOLE_ICON_BASE_URL || DEFAULT_ICON_BASE_URL).trim()

  const rows = list
    .map((it: any) => {
      const name = String(it?.itemName ?? it?.name ?? '').trim()
      if (!name) return null

      const category = String(it?.itemCategory ?? it?.category ?? it?.categoryName ?? 'Unknown').trim() || 'Unknown'
      const imgName = String(it?.imgName ?? it?.imageName ?? it?.image_name ?? '').trim()

      const slugSource = imgName || name
      const slug = slugify(slugSource)
      if (!slug) return null

      const unit = normalizeUnit(category, String(it?.itemClass ?? it?.className ?? it?.class ?? ''))

      const crateSize = Number(it?.numberProduced ?? it?.amountProduced ?? it?.crateSize ?? it?.crate_size ?? NaN)
      const crate_size = Number.isFinite(crateSize) && crateSize > 1 ? Math.floor(crateSize) : null

      const api_id = it?._id ? String(it._id) : it?.id ? String(it.id) : imgName ? String(imgName) : null
      const image_name = imgName || null

      const slotCount = Number(it?.slotCount ?? it?.slot_count ?? 1)
      const slot_count = Number.isFinite(slotCount) && slotCount > 0 ? Math.floor(slotCount) : 1

      const faction = coerceFaction(it?.faction ?? it?.factions ?? null)

      const icon_url = image_name ? `${iconBase}${image_name.replace(/\.png$/i, '')}.png` : null

      return {
        slug,
        name,
        category,
        unit,
        crate_size,
        slot_count,
        api_id,
        image_name,
        faction,
        meta: { ...it, _icon_url: icon_url },
      }
    })
    .filter(Boolean) as any[]

  const dedup = new Map<string, any>()
  for (const r of rows) dedup.set(r.slug, r)
  const finalRows = Array.from(dedup.values())

  const admin = createAdminClient()
  const { error } = await admin.from('items').upsert(finalRows, { onConflict: 'slug' })
  if (error) return json({ error: error.message }, 400)

  return json({ ok: true, upserted: finalRows.length, source: url })
}
