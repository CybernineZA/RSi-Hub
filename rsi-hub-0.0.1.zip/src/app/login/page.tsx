import { Button, Card, CardContent, CardHeader, Badge } from '@/components/ui'
import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

function errorMessage(code?: string) {
  switch (code) {
    case 'not_approved':
      return 'Your Discord login is not approved yet. Apply to join, then wait for an officer to approve you.'
    case 'missing_discord_id':
      return 'Discord login succeeded, but we could not read your Discord User ID. Try again, or contact an officer.'
    case 'missing_regiment':
      return 'Regiment not found in the database. Run the Supabase schema seed and try again.'
    case 'provision_failed':
      return 'Login succeeded but provisioning failed on the server. Check your terminal logs.'
    case 'oauth':
      return 'Discord OAuth failed. Check Supabase provider settings + redirect URLs.'
    case 'missing_code':
      return 'Missing OAuth code. Try logging in again.'
    default:
      return null
  }
}

export default async function LoginPage({
  searchParams,
}: {
  // Next.js 16+ treats searchParams as an async dynamic API in Server Components.
  // When present, it may be a Promise.
  searchParams?: Promise<Record<string, string | string[] | undefined>>
}) {
  const supabase = await createClient()
  const { data } = await supabase.auth.getUser()
  if (data?.user) redirect('/app')

  const sp = searchParams ? await searchParams : {}
  const errorParam = Array.isArray(sp.error) ? sp.error[0] : sp.error
  const err = errorMessage(typeof errorParam === 'string' ? errorParam : undefined)

  async function signInDiscord() {
    'use server'
    const supabase = await createClient()

    const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000').replace(/\/$/, '')
    const redirectTo = `${siteUrl}/auth/callback`

    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'discord',
      options: {
        redirectTo,
        scopes: 'identify',
      },
    })

    if (error) {
      console.error('signInWithOAuth error:', error)
      redirect('/login?error=oauth')
    }

    redirect(data.url)
  }

  return (
    <div className="mx-auto max-w-md px-6 py-16">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-neutral-400">RSi Hub</div>
              <h1 className="text-2xl font-semibold">Login</h1>
            </div>
            <Badge>Discord</Badge>
          </div>

          <p className="mt-2 text-sm text-neutral-300">
            Discord-only access for approved members. If you’re new, apply to join first.
          </p>

          {err ? (
            <div className="mt-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-200">
              {err}
            </div>
          ) : null}
        </CardHeader>

        <CardContent className="space-y-3">
          <form action={signInDiscord}>
            <Button className="w-full">Login with Discord</Button>
          </form>

          <a href="/join" className="block">
            <Button variant="outline" className="w-full">
              Apply to join
            </Button>
          </a>

          <a href="/" className="block text-center text-sm text-neutral-500 hover:text-neutral-300">
            Back to homepage
          </a>
        </CardContent>
      </Card>
    </div>
  )
}
