-- RSi Hub v3.2 patch: add columns needed for Foxhole item sync + richer UI
-- Run in Supabase SQL Editor (Database > SQL Editor)

alter table public.items
  add column if not exists api_id text null,
  add column if not exists image_name text null,
  add column if not exists faction text[] not null default '{}';

-- Helpful unique index if you later want to upsert by api_id (optional)
create unique index if not exists items_api_id_unique
on public.items(api_id)
where api_id is not null;

-- Ask PostgREST to reload schema cache (Supabase sometimes needs this)
notify pgrst, 'reload schema';
